<?php
$id ="";
 if (isset($_GET['id'])){
    $id =  htmlentities($_GET['id']);
    echo $id;
   }
  include_once('tools.php');

  topModule('Product');
?>
<div class="flex-container" id="big">
<?php
 /* $fp = fopen('products.txt','r'); 
  if (($headings = fgetcsv($fp, 0, "\t")) !== false) { 
     while ( $cells = fgetcsv($fp, 0, "\t") )
      { 
         for ($x=1; $x<count($cells); $x++) 
         {  $products[$cells[0]][$headings[$x]]=$cells[$x]; 
           echo $products[$cells[0]][$headings[$x]];
           echo "<br>";
         }
         echo "loop<br>";
      } 
     } 
     fclose($fp);*/
     $lines = explode( "\n", file_get_contents( 'products.txt' ) );
    $headers = str_getcsv( array_shift( $lines ) );
    $products = array();
    foreach ( $lines as $line ) {
	    $row = array();
	foreach ( str_getcsv( $line ) as $key => $field )
		$row[ $headers[ $key ] ] = $field;
	    $row = array_filter( $row );
	    $products[] = $row;
    }
     foreach ($products as $id=>$details)
     {
         echo print_r($details,true);
         /*echo $details['ID'];
         if($details['ID']==$id)
         {
             echo "Got the product";
         }*/
     }
  
?>
<?php
/*
 $productFile = fopen("products.txt","r") or die("Unable to open products.txt");
 $productsStr = fread( $productFile,filesize("products.txt"));
 fclose($productFile);
 $productsLineArr = explode("\n",$productsStr);  //Cutting up file into different lines
 $index = 0;
 foreach($productsLineArr as $line)
 {
     
     if($index == -1)
     {
         $index++;
         continue;
     }
     $tmpArr = explode("\t",$line);
     $productsArray[$index]['ID'] = $tmpArr[0];
     $productsArray[$index]['OID'] = $tmpArr[1];
     $productsArray[$index]['title'] = $tmpArr[2];
     $productsArray[$index]['description'] = $tmpArr[3];
     $productsArray[$index]['option'] = $tmpArr[4];
     $productsArray[$index]['price'] = $tmpArr[5];
     $productsArray[$index]['image'] = $tmpArr[6];
     $index++;
   
 } print_r($productsArray);
 
 echo $productsArray[$id]['image'];
?>

    <div id="picHolder">
        <!-- Original image below sourced for educational purposes: https://www.pexels.com/photo/black-haired-man-wearing-black-sunglasses-and-black-leather-jacket-157966/ -->
        <img src="../../media/<?php echo $productsArray[$id]['image'];?>.jpg">
    </div>

    <div class="bigText">
        <small>Product code : <?php echo $productsArray[$id]['ID']; ?> </small>
        <h1><?php echo $productsArray[$id]["title"] ?></h1>
        <h2>$<?php echo $productsArray[$id]['price'] ?></h2>
        <form action="https://titan.csit.rmit.edu.au/~e54061/wp/processing.php" method="post">
            <input type="hidden" id="porductID" name="<?php echo $productsArray[$id]['ID'] ?>" value="02XXS1">
            <strong>Total Price :</strong> <p id="price" value="80">80<p>
            <label for="size">Size:</label><br>
            <select id="size" name="option">
                <option value="small">Small</option>
                <option value="large">Large</option>
            </select>
            <div class="quantityBox">
                <label>Quantity:</label><br>
                <input type="button" value="-" id="minus" field="quantity" onclick="minusValue()">
                <input type='number' name='qty' value='0' min=1 id='qty'>
                <input type="button" value="+" id="plus" field="quantity" onclick="plusValue()">

                <input type="submit" value="Add to Bag" onclick="check()">
            </div>
        </form>
        <p><?php echo $productsArray[$id]['price']; ?></p>
    </div>

</div>
<!--End of flex-container-->
*/
?>
<?php
  footer();
  
?>