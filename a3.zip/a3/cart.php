<?php
 
  include_once('tools.php');

  topModule('Cart');
?>

<?php
  footer();
  ?>